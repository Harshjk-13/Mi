const express = require("express");
const Exam = require("../models/Exam");
const { protect, adminOnly } = require("../middleware/auth");
const router = express.Router();

router.use(protect);

router.get("/", async (req, res, next) => {
  try {
    const exams = await Exam.find().select("-questions.correctAnswer").sort({ startAt: 1 });
    res.json(exams);
  } catch (err) { next(err); }
});

router.get("/:id", async (req, res, next) => {
  try {
    const exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ message: "Exam not found" });
    const data = exam.toObject();
    if (req.user.role !== "admin") data.questions = data.questions.map(({ correctAnswer, ...q }) => q);
    res.json(data);
  } catch (err) { next(err); }
});

router.post("/", adminOnly, async (req, res, next) => {
  try {
    const { title, subject, description, startAt, durationMinutes, questions = [], status } = req.body;
    if (!title || !subject || !startAt || !durationMinutes || !questions.length)
      return res.status(400).json({ message: "Title, subject, start date, duration and questions are required" });
    const totalMarks = questions.reduce((sum, q) => sum + Number(q.marks || 1), 0);
    const exam = await Exam.create({ title, subject, description, startAt, durationMinutes, questions, totalMarks, status, createdBy: req.user._id });
    req.app.get("io")?.emit("exam-created", { title: exam.title });
    res.status(201).json(exam);
  } catch (err) { next(err); }
});

router.put("/:id", adminOnly, async (req, res, next) => {
  try {
    const update = { ...req.body };
    if (update.questions) update.totalMarks = update.questions.reduce((s, q) => s + Number(q.marks || 1), 0);
    const exam = await Exam.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!exam) return res.status(404).json({ message: "Exam not found" });
    res.json(exam);
  } catch (err) { next(err); }
});

router.delete("/:id", adminOnly, async (req, res, next) => {
  try {
    const exam = await Exam.findByIdAndDelete(req.params.id);
    if (!exam) return res.status(404).json({ message: "Exam not found" });
    res.json({ message: "Exam deleted successfully" });
  } catch (err) { next(err); }
});

module.exports = router;
