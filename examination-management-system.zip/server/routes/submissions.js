const express = require("express");
const Exam = require("../models/Exam");
const Submission = require("../models/Submission");
const { protect, adminOnly } = require("../middleware/auth");
const router = express.Router();

router.use(protect);

router.post("/:examId", async (req, res, next) => {
  try {
    if (req.user.role !== "student") return res.status(403).json({ message: "Only students can submit exams" });
    const exam = await Exam.findById(req.params.examId);
    if (!exam) return res.status(404).json({ message: "Exam not found" });
    const now = Date.now();
    const start = new Date(exam.startAt).getTime();
    const end = start + exam.durationMinutes * 60000;
    if (now < start || now > end) return res.status(400).json({ message: "This examination is not currently open" });
    const existing = await Submission.findOne({ exam: exam._id, student: req.user._id });
    if (existing) return res.status(409).json({ message: "You have already submitted this exam" });

    const answers = Array.isArray(req.body.answers) ? req.body.answers : [];
    let score = 0;
    answers.forEach(a => {
      const q = exam.questions[Number(a.questionIndex)];
      if (q && Number(a.selectedOption) === q.correctAnswer) score += q.marks;
    });
    const submission = await Submission.create({
      exam: exam._id, student: req.user._id, answers, score, totalMarks: exam.totalMarks
    });
    res.status(201).json({ message: "Exam submitted successfully", result: submission });
  } catch (err) { next(err); }
});

router.get("/my/results", async (req, res, next) => {
  try {
    const results = await Submission.find({ student: req.user._id }).populate("exam", "title subject startAt totalMarks").sort({ submittedAt: -1 });
    res.json(results);
  } catch (err) { next(err); }
});

router.get("/", adminOnly, async (req, res, next) => {
  try {
    const submissions = await Submission.find().populate("student", "name email studentId").populate("exam", "title subject").sort({ submittedAt: -1 });
    res.json(submissions);
  } catch (err) { next(err); }
});

module.exports = router;
