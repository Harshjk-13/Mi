# Examination Management System (EMS)

A MERN-stack starter project for managing students, examinations, online attempts and results.

## Roles
- **Admin:** create exams/questions, view students and submissions, publish results.
- **Student:** register/login, view scheduled exams, attempt exams, view results.

## Tech stack
React + Vite + Tailwind CSS, Node.js + Express, MongoDB + Mongoose, JWT + bcrypt, Socket.IO.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas connection string

## Run locally

### 1. Backend
```bash
cd server
npm install
cp .env.example .env
# Edit .env and set MONGO_URI and JWT_SECRET
npm run dev
```
Backend runs at `http://localhost:5000`.

### 2. Frontend
Open a second terminal:
```bash
cd client
npm install
cp .env.example .env
npm run dev
```
Open the Vite URL shown in the terminal (usually `http://localhost:5173`).

## Create the first admin
1. Register a user from the UI.
2. In MongoDB, update that user's `role` field to `admin`.
3. Log in again. Public self-registration always creates a `student` account.

Example MongoDB update:
```js
db.users.updateOne({ email: "admin@example.com" }, { $set: { role: "admin" } })
```

## Main API routes
| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register student |
| POST | `/api/auth/login` | Public | Login |
| GET | `/api/auth/me` | Logged in | Current user |
| GET | `/api/exams` | Logged in | List exams |
| GET | `/api/exams/:id` | Logged in | Exam details |
| POST | `/api/exams` | Admin | Create exam |
| PUT | `/api/exams/:id` | Admin | Update exam |
| DELETE | `/api/exams/:id` | Admin | Delete exam |
| POST | `/api/submissions/:examId` | Student | Submit answers |
| GET | `/api/submissions/my/results` | Student | Own results |
| GET | `/api/submissions` | Admin | All submissions |

## Project structure
```text
examination-management-system/
├── client/
│   ├── src/
│   │   ├── components/
│   │   ├── context/
│   │   ├── hooks/
│   │   ├── pages/
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── ...
└── server/
    ├── config/
    ├── middleware/
    ├── models/
    ├── routes/
    └── server.js
```

## Notes
- Objective questions are automatically evaluated by the server.
- The API validates inputs, hashes passwords, uses JWT-protected routes, and checks roles.
- Configure a strong JWT secret and use HTTPS in production.
- This is an academic starter implementation. Before real institutional use, add audit logs, stronger rate limiting, backups, accessibility testing, proctoring policies and security review.
