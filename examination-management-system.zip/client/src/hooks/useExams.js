import { useEffect, useState } from "react";
import api from "../api";

export default function useExams() {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    api.get("/exams")
      .then(({ data }) => { if (active) setExams(data); })
      .catch(err => { if (active) setError(err.response?.data?.message || "Could not load examinations"); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  return { exams, loading, error, setExams };
}
