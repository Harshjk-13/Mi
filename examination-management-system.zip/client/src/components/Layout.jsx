import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { BookOpenCheck, LayoutDashboard, ClipboardList, Trophy, LogOut, Menu, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function Layout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const links = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard },
    { to: "/exams", label: "Examinations", icon: ClipboardList },
    ...(user?.role === "student" ? [{ to: "/results", label: "My Results", icon: Trophy }] : [])
  ];
  function signOut() { logout(); navigate("/login"); }
  return <div className="min-h-screen md:flex">
    <aside className={`${open ? "block" : "hidden"} fixed inset-y-0 left-0 z-30 w-64 bg-slate-950 p-5 text-white md:static md:block`}>
      <div className="mb-10 flex items-center justify-between"><Link to="/" className="flex items-center gap-2 text-xl font-bold"><BookOpenCheck className="text-indigo-400"/> ExamFlow</Link><button className="md:hidden" onClick={() => setOpen(false)}><X/></button></div>
      <p className="mb-3 text-xs uppercase tracking-widest text-slate-400">Workspace</p>
      <nav className="space-y-2">{links.map(item => <NavLink key={item.to} to={item.to} onClick={() => setOpen(false)} className={({isActive}) => `flex items-center gap-3 rounded-xl px-3 py-3 text-sm ${isActive ? "bg-indigo-600 text-white" : "text-slate-300 hover:bg-slate-800"}`}><item.icon size={18}/>{item.label}</NavLink>)}</nav>
      <div className="absolute bottom-5 left-5 right-5"><div className="mb-3 rounded-xl bg-slate-900 p-3"><p className="font-semibold">{user?.name}</p><p className="text-xs capitalize text-slate-400">{user?.role}</p></div><button onClick={signOut} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-slate-300 hover:bg-slate-800"><LogOut size={17}/> Sign out</button></div>
    </aside>
    <main className="min-w-0 flex-1"><header className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4 md:px-8"><button className="md:hidden" onClick={() => setOpen(true)}><Menu/></button><div><p className="font-semibold">Examination Portal</p><p className="text-xs text-slate-500">Manage your academic journey</p></div><div className="hidden rounded-full bg-indigo-50 px-4 py-2 text-sm font-medium text-indigo-700 sm:block">{user?.role === "admin" ? "Administrator" : "Student Portal"}</div></header><div className="p-5 md:p-8"><Outlet/></div></main>
  </div>;
}
