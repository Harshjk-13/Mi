import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Exams from "./pages/Exams";
import Results from "./pages/Results";
import Attempt from "./pages/Attempt";

function AppRoutes() {
  const { user } = useAuth();
  return <Routes>
    <Route path="/login" element={user?<Navigate to="/" replace/>:<Login/>}/>
    <Route path="/register" element={user?<Navigate to="/" replace/>:<Register/>}/>
    <Route path="/" element={<ProtectedRoute><Layout/></ProtectedRoute>}>
      <Route index element={<Dashboard/>}/>
      <Route path="exams" element={<Exams/>}/>
      <Route path="exams/:id/attempt" element={<Attempt/>}/>
      <Route path="results" element={<Results/>}/>
    </Route>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes>;
}
export default function App() {
  return <AuthProvider><BrowserRouter><AppRoutes/></BrowserRouter></AuthProvider>;
}
