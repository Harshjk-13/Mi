import { createContext, useContext, useState } from "react";
import api from "../api";

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ems_user")); } catch { return null; }
  });
  async function login(credentials) {
    const { data } = await api.post("/auth/login", credentials);
    localStorage.setItem("ems_token", data.token);
    localStorage.setItem("ems_user", JSON.stringify(data.user));
    setUser(data.user);
  }
  async function register(details) {
    const { data } = await api.post("/auth/register", details);
    localStorage.setItem("ems_token", data.token);
    localStorage.setItem("ems_user", JSON.stringify(data.user));
    setUser(data.user);
  }
  function logout() {
    localStorage.removeItem("ems_token");
    localStorage.removeItem("ems_user");
    setUser(null);
  }
  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
