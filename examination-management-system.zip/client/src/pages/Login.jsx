import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BookOpenCheck } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth(); const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try { await login(form); navigate("/"); }
    catch (err) { setError(err.response?.data?.message || "Login failed"); }
    finally { setBusy(false); }
  }
  return <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4 py-10"><div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl"><div className="mb-7 text-center"><div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-700"><BookOpenCheck size={28}/></div><h1 className="text-2xl font-bold">Welcome to ExamFlow</h1><p className="mt-1 text-sm text-slate-500">Sign in to your examination portal</p></div>
    {error && <p className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
    <form onSubmit={submit} className="space-y-4"><label className="block text-sm font-medium">Email<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"/></label><label className="block text-sm font-medium">Password<input required type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"/></label><button disabled={busy} className="w-full rounded-xl bg-indigo-600 py-3 font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-60">{busy ? "Signing in..." : "Sign in"}</button></form>
    <p className="mt-6 text-center text-sm text-slate-500">New student? <Link to="/register" className="font-semibold text-indigo-600">Create account</Link></p></div></div>;
}
