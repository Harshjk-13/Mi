import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
export default function Register() {
  const { register } = useAuth(); const navigate = useNavigate();
  const [form,setForm] = useState({name:"",email:"",studentId:"",password:""});
  const [error,setError] = useState(""); const [busy,setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setError(""); setBusy(true); try { await register(form); navigate("/"); } catch(err) { setError(err.response?.data?.message || "Registration failed"); } finally { setBusy(false); } }
  return <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4 py-10"><div className="w-full max-w-md rounded-3xl bg-white p-8"><h1 className="text-2xl font-bold">Create student account</h1><p className="mb-6 mt-1 text-sm text-slate-500">Register to access examinations</p>{error && <p className="mb-3 rounded bg-red-50 p-3 text-sm text-red-700">{error}</p>}<form onSubmit={submit} className="space-y-3">{[["name","Full name","text"],["email","Email address","email"],["studentId","Student ID","text"],["password","Password (min. 6 characters)","password"]].map(([key,label,type])=><label key={key} className="block text-sm font-medium">{label}<input required type={type} minLength={key==="password"?6:undefined} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3"/></label>)}<button disabled={busy} className="w-full rounded-xl bg-indigo-600 py-3 font-semibold text-white">{busy?"Creating...":"Create account"}</button></form><p className="mt-5 text-center text-sm text-slate-500">Already registered? <Link to="/login" className="text-indigo-600">Sign in</Link></p></div></div>;
}
