import { useEffect, useState } from "react";
import { Trophy } from "lucide-react";
import api from "../api";
export default function Results() {
  const [results,setResults] = useState([]); const [error,setError] = useState("");
  useEffect(()=>{api.get("/submissions/my/results").then(({data})=>setResults(data)).catch(err=>setError(err.response?.data?.message||"Could not load results"));},[]);
  return <div className="mx-auto max-w-5xl"><div className="mb-6"><p className="text-sm font-semibold text-indigo-600">PERFORMANCE</p><h1 className="mt-1 text-3xl font-bold">My Results</h1><p className="mt-2 text-slate-500">Review your submitted examination scores.</p></div>{error&&<p className="text-red-600">{error}</p>}{results.length===0?<div className="rounded-2xl border border-dashed bg-white p-10 text-center text-slate-500"><Trophy className="mx-auto mb-3" size={30}/>No results available yet.</div>:<div className="overflow-hidden rounded-2xl border bg-white"><table className="w-full text-left text-sm"><thead className="bg-slate-50 text-slate-500"><tr><th className="p-4">Examination</th><th className="p-4">Subject</th><th className="p-4">Score</th><th className="p-4">Submitted</th></tr></thead><tbody>{results.map(r=><tr key={r._id} className="border-t"><td className="p-4 font-semibold">{r.exam?.title||"Exam"}</td><td className="p-4">{r.exam?.subject||"—"}</td><td className="p-4 font-bold text-indigo-700">{r.score} / {r.totalMarks}</td><td className="p-4">{new Date(r.submittedAt).toLocaleString()}</td></tr>)}</tbody></table></div>}</div>;
}
