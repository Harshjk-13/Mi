import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api";

export default function Attempt() {
  const { id } = useParams(); const navigate = useNavigate();
  const [exam,setExam] = useState(null); const [answers,setAnswers] = useState({});
  const [loading,setLoading] = useState(true); const [error,setError] = useState(""); const [busy,setBusy] = useState(false);
  useEffect(()=>{api.get(`/exams/${id}`).then(({data})=>setExam(data)).catch(err=>setError(err.response?.data?.message||"Could not load exam")).finally(()=>setLoading(false));},[id]);
  async function submit(e) {
    e.preventDefault();
    if (!window.confirm("Submit your answers? You cannot submit this exam again.")) return;
    setBusy(true); setError("");
    try {
      const payload = Object.entries(answers).map(([questionIndex,selectedOption])=>({questionIndex:Number(questionIndex),selectedOption:Number(selectedOption)}));
      const {data} = await api.post(`/submissions/${id}`,{answers:payload});
      window.alert(`Submitted successfully. Your score: ${data.result.score}/${data.result.totalMarks}`);
      navigate("/results");
    } catch(err) { setError(err.response?.data?.message||"Submission failed"); }
    finally { setBusy(false); }
  }
  if (loading) return <p>Loading examination...</p>;
  if (!exam) return <p className="rounded-xl bg-red-50 p-4 text-red-700">{error||"Exam not found"}</p>;
  const open = Date.now() >= new Date(exam.startAt).getTime() && Date.now() <= new Date(exam.startAt).getTime()+exam.durationMinutes*60000;
  return <div className="mx-auto max-w-3xl"><button onClick={()=>navigate("/exams")} className="mb-4 text-sm font-semibold text-indigo-600">← Back to examinations</button><div className="mb-6 rounded-2xl bg-indigo-700 p-6 text-white"><p className="text-sm text-indigo-200">{exam.subject}</p><h1 className="mt-1 text-2xl font-bold">{exam.title}</h1><p className="mt-2 text-sm text-indigo-100">{exam.durationMinutes} minutes · {exam.totalMarks} marks</p></div>{!open&&<p className="mb-4 rounded-xl bg-amber-50 p-4 text-amber-800">This exam is not currently open. Scheduled start: {new Date(exam.startAt).toLocaleString()}.</p>}{error&&<p className="mb-4 rounded-xl bg-red-50 p-3 text-red-700">{error}</p>}<form onSubmit={submit} className="space-y-5">{exam.questions.map((q,i)=><section key={q._id||i} className="rounded-2xl border bg-white p-5"><div className="mb-4 flex justify-between gap-3"><h2 className="font-semibold">{i+1}. {q.text}</h2><span className="whitespace-nowrap text-xs text-slate-500">{q.marks} mark(s)</span></div><div className="space-y-2">{q.options.map((option,j)=><label key={j} className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-sm hover:border-indigo-400 ${answers[i]===j?"border-indigo-500 bg-indigo-50":""}`}><input type="radio" name={`question-${i}`} checked={answers[i]===j} onChange={()=>setAnswers(prev=>({...prev,[i]:j}))}/>{option}</label>)}</div></section>)}<button disabled={!open||busy||exam.questions.length===0} className="w-full rounded-xl bg-indigo-600 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50">{busy?"Submitting...":"Submit examination"}</button></form></div>;
}
